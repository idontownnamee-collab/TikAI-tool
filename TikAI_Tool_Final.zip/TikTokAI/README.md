# 🎵 TikAI Tool — Advanced TikTok Companion App

A powerful Android tool for TikTok with **one-tap open**, **watermark-free downloads**, and a **built-in AI Finder** that lets you crop any part of a video and instantly identify it.

---

## ✨ Features

### 🤖 AI Finder (Main Feature)
- **Floating FIND button** appears on the left side of your screen while watching TikTok
- **Drag** the button anywhere on screen
- **Tap it** → full screen is captured → draw a crop box around anything:
  - A CODM avatar/skin → AI tells you the exact name + how to get it
  - An anime character → full name, series, facts
  - A product → brand, name, where to buy
  - A game item → rarity, how to unlock
- **Powered by Claude AI** (claude-opus-4)

### 📥 Easy Download
- Paste any TikTok URL → downloads video **without watermark**
- Background download with progress notification
- Saved to `Movies/TikAI/` on your device

### ⚡ One-Click Open
- Opens TikTok directly (works with both global and regional TikTok apps)
- Auto-activates AI overlay when TikTok launches

### ⚙️ Customizable
- Custom AI analysis prompt
- Toggle overlay on/off
- Save/share AI results
- History of past analyses

---

## 🛠️ How to Build

### Requirements
- **Android Studio** Hedgehog (2023.1.1) or newer
- **JDK 17**
- **Android SDK** with API 34
- A **Claude API key** from [console.anthropic.com](https://console.anthropic.com)

### Steps

1. **Open in Android Studio**
   ```
   File → Open → Select TikTokAI/ folder
   ```

2. **Let Gradle sync** (it will download all dependencies automatically)

3. **Add vector drawables** — Android Studio will prompt to generate missing drawables. You need these in `res/drawable/`:
   - `ic_settings.xml`
   - `ic_back.xml`
   - `ic_download.xml`
   - `ic_ai_finder.xml`
   - `ic_close.xml`
   - `ic_arrow_right.xml`
   
   Or use **File → New → Vector Asset** to create them from Material Icons.

4. **Add Markwon dependency** to `app/build.gradle`:
   ```gradle
   implementation 'io.noties.markwon:core:4.6.2'
   ```

5. **Add launcher icons** — Right-click `res/` → New → Image Asset → choose an icon

6. **Build APK**:
   - `Build → Build Bundle(s)/APK(s) → Build APK(s)`
   - Or run: `./gradlew assembleDebug`
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

7. **Install on your Android phone**:
   ```
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 📱 First-Time Setup

1. Open **TikAI Tool**
2. Tap **⚙️ Settings**
3. Enter your **Claude API key** (from console.anthropic.com)
4. Save settings
5. Tap **🤖 AI Finder** — grant "Display over other apps" permission when asked
6. TikTok will open with the **FIND button** on the left side of the screen

---

## 🎮 Using the AI Finder

```
1. Open TikTok via the app (or manually, overlay stays active)
2. Watch a video — pause when you see something you want to identify
3. TAP the purple FIND button on the left edge of screen
4. A screenshot is taken → draw a box around what you want
5. Tap DONE
6. AI analyzes it and shows:
   - Name / Title
   - Category (game/anime/product/etc)
   - Detailed info
   - How to get/find it
   - Extra tips
```

---

## ⚠️ Permissions Explained

| Permission | Why |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Show FIND button over TikTok |
| `FOREGROUND_SERVICE` | Keep overlay active |
| `INTERNET` | Send image to Claude AI, download videos |
| `MEDIA_PROJECTION` | Take screenshot for AI analysis |
| `WRITE_EXTERNAL_STORAGE` | Save downloaded videos |

---

## 📁 Project Structure

```
TikTokAI/
├── app/src/main/
│   ├── java/com/tiktokaitool/
│   │   ├── ui/
│   │   │   ├── MainActivity.kt          ← Main hub
│   │   │   ├── CropAnalyzeActivity.kt   ← Crop + AI
│   │   │   ├── CropOverlayView.kt       ← Custom crop drawing
│   │   │   ├── ResultActivity.kt        ← AI result display
│   │   │   ├── DownloadsActivity.kt     ← Download manager
│   │   │   └── SettingsActivity.kt      ← Settings
│   │   ├── service/
│   │   │   ├── OverlayService.kt        ← Floating FIND button
│   │   │   └── DownloadService.kt       ← Background download
│   │   ├── api/
│   │   │   └── ClaudeAnalyzer.kt        ← Claude API integration
│   │   └── utils/
│   │       ├── PrefsManager.kt          ← Settings storage
│   │       ├── HistoryManager.kt        ← History storage
│   │       ├── TikTokUtils.kt           ← URL parsing
│   │       └── ScreenCaptureHelper.kt   ← Screenshot capture
│   └── res/
│       ├── layout/                      ← All XML layouts
│       ├── drawable/                    ← Icons & shapes
│       └── values/                      ← Colors, strings, themes
```

---

## 🔧 Tech Stack
- **Kotlin** — Android development
- **Claude API (claude-opus-4)** — AI image analysis
- **OkHttp** — Network requests
- **MediaProjection API** — Screen capture
- **Markwon** — Markdown rendering for AI results
- **Material Design 3** — UI components
- **Coroutines** — Async operations
